package ExtRobot;

use Moo::Role;

requires 'beep';

1;
